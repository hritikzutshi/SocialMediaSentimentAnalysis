# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.test import TestCase

# Create your tests here.
from django.db import models
class Hashtag:
    ht1:str
    ht2:str
    ht3:str
    ht4:str
    ht5:str
